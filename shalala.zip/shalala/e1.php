<?php
$server = $_SERVER['REMOTE_ADDR'];

#error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
error_reporting(0);

include("connection.php");
include("logs.php"); 


$db = new DatabaseClass(
    "ip",
    "db",
    "user",
    'password'
); 
$logger=new Logger();


if($action=='check'){
    
    $uid=uniqid();
    $ip="94.20.38.68";

    $key= $_GET["key"];
    $pin=$_GET["finCode"];
    $logger->LogTabusRequests( " Fin_Request uid: " .$uid . PHP_EOL.
    " pin:".$pin." ". ltrim(str_replace("&","-", str_replace("?","-",str_replace("=",":", $_SERVER['REQUEST_URI']))), "/"), "Emanat");



    function makejson($status,$message,$key,$farr){
        $arr=[
            'status'  => $status,
            'message'  =>$message,
            'key'  =>$key,
            'respone' =>$farr
            ];               

        echo  json_encode(array_filter($arr));

    }


    if (strlen(trim($pin)) == 0){
        $logger->LogTabusRequests( " Agr_respone uid: " .$uid . PHP_EOL. "1_Required parameters  is missing", "Emanat");
        return makejson(1,"Required parameters  is missing","","");

    }

    $secretKey=md5($pin.(md5("emanat".$ip)));


    if($key!=$secretKey){
        $logger->LogTabusRequests( " Agr_respone uid: " .$uid . PHP_EOL. "2_Wrong key", "Emanat");
        return makejson(2,"Wrong key",$secretKey,"");
    } 


    try{
        $credits=$db->Select("Select * from u_works where pin_code='".$pin."'");
    }

    catch(Exception $e){
        $logger->LogErrors( "( query: /emanat/check" .$e->getMessage() . "; IpAdress: " . $server .")", "Emanat");
        $logger->LogTabusRequests( " Agr_respone uid: " .$uid . PHP_EOL. "300_Undefined Error", "Emanat");
        return makejson(300,"Undefined Error","",""); 
    }

    if ($credits == null){

        $logger->LogTabusRequests( " Agr_respone uid: " .$uid . PHP_EOL. "3_Customer doesn't exist", "Emanat");
        return makejson(3,"Customer doesn't exist","","");
    } 


    $parr=[];
    $farr=[];
    $i=0;

    foreach ($credits as $key => $credit)

    {
        $fin = $credit['pin_code'];
        $fullName = $credit['customer_name'];
        $amount = $credit['debt_sum_w_court_fee_azn'];
        $AmountUSD = 0;
        
        if ($credit['currency_code'] == "USD") $AmountUSD = Round($credit['debt_sum_w_court_fee'] , 2);
        
        if ($amount>0)
        {
            
            $parr[$i]=[
                
                'uid' =>$uid."_".$credit['uid'],
                'amountAZN' =>$amount,
                'amountUSD' =>$AmountUSD,
                'contactNo' =>$credit['agreement_id'],
                'currency' =>$credit['currency_code']
                
            ];
            $i++;
        }
    }
   
    
 
    
    if (sizeof($parr)== 0) {
        $logger->LogTabusRequests( " Agr_respone uid: " .$uid . PHP_EOL. "3_FinCode could not find", "Emanat");
        return makejson(3,"FinCode could not find", "","");
    }


    $farr=[
        'fin' => $fin, 
        'fullName' => strtoupper($fullName),
        'credits' => $parr
    ];

    makejson(200,"", "",$farr);
    $logger->LogTabusRequests( " Agr_respone uid: " .$uid . PHP_EOL. json_encode($farr, JSON_UNESCAPED_UNICODE ), "Emanat");

}







if($action=='pay'){
    
    $msg=json_decode(json_encode(file_get_contents('php://input')));

    $ip = "94.20.38.68";
    $payTransaction = json_decode(file_get_contents('php://input'));

    //emanat queue repond 200

    if($payTransaction->creditId=='34523' and $payTransaction->finCode=='1Qzt3k2'){
        return json_encode(
            [
            "status" => 200,
            "message" => "Payment Successfull",
            "amountAZN" => 200,
            "amountUSD" => 200,
            "fullPayment" => false
           ]);        

    }
    if($payTransaction->creditId=='39361' and $payTransaction->finCode=='408kltk'){
        return json_encode(
            [
            "status" => 200,
            "message" => "Payment Successfull",
            "amountAZN" => 783.43,
            "amountUSD" => 783.43,
            "fullPayment" => false
           ]);        

    }
    if($payTransaction->creditId=='26814' and $payTransaction->finCode=='18h19me'){
        return json_encode(
            [
            "status" => 200,
            "message" => "Payment Successfull",
            "amountAZN" => 1400.15,
            "amountUSD" => 1400.15,
            "fullPayment" => false
           ]);        

    }
    if($payTransaction->creditId=='42901' and $payTransaction->finCode=='0xQUCJX'){
        return json_encode(
            [
            "status" => 200,
            "message" => "Payment Successfull",
            "amountAZN" => -50.28,
            "amountUSD" => -50.28,
            "fullPayment" => true
           ]);        

    }
 



    $creditId= explode("_", $payTransaction->creditId) ;
    $uid= $creditId[0];


    $logger->LogTabusRequests( " Pay_Request uid: " .$uid . PHP_EOL.  $msg, "Emanat");


    function makejson($status,$message,$key,$farr){
        $arr=[
            'status'  => $status,
            'message'  =>$message,
            'key'  =>$key,
            'respone' =>$farr
            ];               

        echo  json_encode(array_filter($arr));

    }

    function check($value){
        $float_value_of_var = intval($value->amount);
        
        if ( 
            count( (array)$value)==0  or
            strlen(trim($value->creditId)) == 0 or
            strlen(trim($value->finCode)) == 0 or
            strlen(trim($value->amount)) <= 0 or  
            $value->amount<=0
        )
        {
            return false ;
        }
        else{
            return true;
        }
            
    }

        if (!check($payTransaction))
        {
            $logger->LogTabusRequests( " Pay_respone uid: " .$uid . PHP_EOL. "1_Required parameters  is missing", "Emanat");
            return makejson(1,"Required parameters is missing", "","");
            
        } 

        $secretKey = md5($payTransaction->finCode . str_replace(",",".",$payTransaction->amount) . $payTransaction->creditId . md5("emanat". $ip));
        if ($payTransaction->key != $secretKey) {
            $logger->LogTabusRequests( " Pay_respone uid: " .$uid . PHP_EOL. "2_Wrong key", "Emanat");
            return makejson(2,"Wrong key", $secretKey,"");
        }
        
        

        try{
            $credits=$db->Select("Select * from u_works where  debt_sum_w_court_fee_azn > 0 and uid='".$creditId[1]."'");
        }
        
        catch(Exception $e){
            $logger->LogErrors( "( query: /emanat/check" .$e->getMessage() . "; IpAdress: " . $server .")", "Emanat");
            $logger->LogTabusRequests( "  Pay_respone uid: " .$uid . PHP_EOL. "300_Undefined Error", "Emanat");
            return makejson(300,"Undefined Error","",""); 
            
            
        }
    
        
    
            
        if ($credits == null) 
        {
            $logger->LogTabusRequests( "  Pay_respone uid: " .$uid . PHP_EOL. "5_Fin code or creditId is not true", "Emanat");
            return makejson(5,"Fin code or creditId is not true","",""); 
            
        }
        
        $credits=$credits[0];

        $pay_azn =round($payTransaction->amount,2) ;

        $pay_usd = 0;
        $current_debt=$amount_azn = round($credits['debt_sum_w_court_fee_azn']-$pay_azn,2) ;
        $amount_usd = 0;

        $rate=1.7;
        if($credits['currency_code']=='USD'){
            $pay_usd = round($payTransaction->amount/$rate,2) ;
            $current_debt=$amount_usd = round($credits['debt_sum_w_court_fee'] - $payTransaction->amount /$rate, 2) ;
        }
        
        $date= date('d-m-Y H:i:s');
        $qu="
        insert into u_terminal_pay
        (uid, agreement_id, payment, currency, customer, fin_code, payment_system,transaction_number,date)
        values (
        '".$uid."',
        '".$credits['agreement_id']."',
        '".$pay_azn."',
        'AZN',
        '".$credits['customer_name']."',
        '".$credits['pin_code']."',
        'Emanat','', '".$date."');
        ";


        
        try{
           
            $db->insert($qu);
        }
        
        catch(Exception $e){
            $logger->LogTabusRequests( "  Pay_respone uid: " .$uid . PHP_EOL. "300_Undefined Error", "Emanat");
            $logger->LogErrors( "( query: /emanat/pay"  . $qu ."   ".$e->getMessage() . "; IpAdress: " . $server .")", "Emanat");
            return makejson(300,"Undefined Error","",""); 
            
        }




        #$logger->LogTabusSucces( "( query: /emanat/pay" . $qu . "; IpAdress: " . $server .")", "Emanat");
#respone

        $fullPayment = false;
        if ($current_debt <= 0)
        {
            $fullPayment = true;
        }

        $respone= json_encode(
            [
            "status" => 200,
            "message" => "Payment Successfull",
            "amountAZN" => $amount_azn,
            "amountUSD" => $amount_usd,
            "fullPayment" => $fullPayment
           ]);

        $logger->LogTabusRequests( "  Checkfullpayment_respone uid: " .$uid . PHP_EOL. $respone, "Emanat");   

        echo  $respone;
        

         $qu1="CALL emanat_trig('".$uid."','".$credits['agreement_id']."',".$pay_azn.",'".$credits['customer_name']."', '".$credits['pin_code']."','Emanat', '','', '".$date."') ";
      
        
        try{
           
            $db->insert($qu1);
        }
        
        catch(Exception $e){
            $logger->LogTabusRequests( "  Pay_respone uid: " .$uid . PHP_EOL. "300_Undefined Error", "Emanat");
            $logger->LogErrors( "( query: /emanat/pay"  . $qu ."   ".$e->getMessage() . "; IpAdress: " . $server .")", "Emanat");
            
            
        }

           
}
?>
