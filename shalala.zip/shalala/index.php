<?php
error_reporting(0);
$server = $_SERVER['REMOTE_ADDR'];

date_default_timezone_set('Asia/Baku');

/*
if (isset($_GET["finCode"])){
    $pins=['000033A','000034A','000054A','0096VFA','12345','','1DUBXZS','mypin','1UHB9DC','2F1H7YG  ','3TNGZLP','1BZ42KZ','250XFCV'];
    if(!in_array($_GET["finCode"],$pins))
    {
        $arr=[
            'status'  => 3,
            'message'  =>"Customer   doesn't existt"
            ];               

        echo  json_encode(array_filter($arr));
        exit;
    }
    


}
*/

global  $company;
global  $action;

 
$request= strtok($_SERVER['REQUEST_URI'], '?');

$arr= explode("/", $request) ;
$company=$arr[1];
$action=$arr[2];
$companies=['emanat','million'];
$actions=['check','pay','checkTransaction'];


if(!in_array($company,$companies)) $company='attack';

function checkrequest($company,$action, $companies,$actions){
    $payTransaction = json_decode(file_get_contents('php://input'));

    #if(isset($_GET["key"]) and isset($_GET["finCode"])) return a=true;


    if ( 
        !in_array($company,$companies) or
        !in_array($action,$actions) or
        ($action=='check' and (!isset($_GET["key"]) or !isset($_GET["finCode"])) ) or
        ($action=='checkTransaction' and (!isset($_GET["key"]) or !isset($_GET["transactNo"])) ) or
        ($action=='pay' and ( !isset($payTransaction->finCode) or !isset($payTransaction->amount) or !isset($payTransaction->creditId) or !isset($payTransaction->key)  ) )

    )
    {
        return true ;
    }
    else{
        return false;
    }
        

}
#/*
if(checkrequest($company,$action, $companies,$actions)){


    json_encode(array_filter( 
    $arr=[
    'status'  => 404,
    'message'  =>"Error"
    ]  ));


    $path = "C:" . DIRECTORY_SEPARATOR . "Logs" ;
    $path1 = $path . DIRECTORY_SEPARATOR . $company ;
    $filePath = $path1. DIRECTORY_SEPARATOR . date("d_m_Y") . "_indexrequests.txt";


    if (!is_dir($path)) mkdir($path, 0700);
    if (!is_dir($path1)) mkdir($path1, 0700);
    if (!file_exists($filePath))
    {
        $message = "[" .date('Y_m_d_H_i_s'). "]: Incorrect request; reuest:" .preg_replace("/[^a-zA-Z0-9]+/", "", $_SERVER['REQUEST_URI']).
        json_decode(json_encode(file_get_contents('php://input'))). "; ip:".$server. PHP_EOL;
        
        $myfile = fopen($filePath, "w") ;
        fwrite($myfile, $message);
        fclose($myfile);
    }
    else 
    {
        $fl=fopen($filePath, "r+");
        $size= filesize($filePath);
        $text = fread($fl,$size);
        $text =  "[" . date('Y_m_d_H_i_s') . "]:Incorrect request; reuest:" .preg_replace("/[^a-zA-Z0-9]+/", "", $_SERVER['REQUEST_URI']).
        json_decode(json_encode(file_get_contents('php://input'))). "; ip:".$server.PHP_EOL;

        
        fwrite($fl, $text);
        fclose($fl);
    }

exit;
}

if($company=='emanat'){
  include("e1.php"); 
}
if($company=='million'){
    include("mi1.php"); 
}
#*/
?>