<?php
date_default_timezone_set('Asia/Baku');


    class Logger
    {
        
        

        private function  DirNotExist($path, $filePath, $message, $folder)
        {
            mkdir($path, 0700);
            if (!is_string(is_null($folder)))
            {
                mkdir($path . DIRECTORY_SEPARATOR . $folder, 0700);
            }
            $this->FileNotExist($filePath, $message);
        }

        private function FileNotExist($filePath, $message)
        {

            $myfile = fopen($filePath, "w") ;
            fwrite($myfile, $message);
            fclose($myfile);

            #using (FileStream fs = File.Create(filePath))
            #{
                // Add some text to file    
               # byte[] title = new UTF8Encoding(true).GetBytes(message);
                #fs.Write(title, 0, title.Length);
            #}

        }
        
        

        
        public function LogErrors($message, $folder)
        {
            
            $path  = "C:" . DIRECTORY_SEPARATOR . "Logs";
            $path1 = $path . DIRECTORY_SEPARATOR . $folder;
            $filePath = $path1 . DIRECTORY_SEPARATOR . date('d_m_Y')."_sqlerrors.txt";
            if (is_dir($path))
            {
                if (is_dir($path1))
                {
                    if (file_exists($filePath))
                    {
                        $fl=fopen($filePath, "r+");
                        $size= filesize($filePath);
                        $text = fread($fl,$size);
                        $text = date('Y-m-d H:i:s') ." Sql didn't response" . $message.PHP_EOL;
                        fwrite($fl, $text);
                        fclose($fl);
                    }
                    else
                    {
                        $message = date('Y-m-d H:i:s'). " Sql didn't response" . $message;
                        $this->FileNotExist($filePath, $message);
                    }
                }
                else
                {
                    $message =  date('Y-m-d H:i:s') . " Sql didn't response" .$message;
                    $this->DirNotExist($path1, $filePath, $message, "");
                }
            }
            else
            {
                $message =  date('Y-m-d H:i:s') . " Sql didn't response" . $message;
                $this->DirNotExist($path, $filePath, $message, $folder);
            }
        }

        /*
        public function LogRequests($message, $folder)
        {
            $path  = "C:\shfolder" . DIRECTORY_SEPARATOR . "Logs";
            $path1 = $path . DIRECTORY_SEPARATOR . $folder;
            $filePath = $path1 . DIRECTORY_SEPARATOR . date('Y-m-d H:i:s')."_requests.txt";
           
            if (is_dir($path))
            {
                if (is_dir($path1))
                {
                    if (file_exists($filePath))
                    {
                        $text = fread($filePath);
                        $text = $text ."\n[" . date('Y-m-d H:i:s') . "]:" . $message;
                        fwrite($myfile, $text);
                        fclose($myfile);
                    }
                    else
                    {
                        $message = date('Y-m-d H:i:s'). "]:" . $message;
                        $this->FileNotExist($filePath, $message);
                    }
                }
                else
                {
                    $message = date('Y-m-d H:i:s') . "]:" . $message;
                    $this->DirNotExist($path1, $filePath, $message, "");
                }
            }
            else
            {
                $message = date('Y-m-d H:i:s') . "]:" . $message;
                $this->DirNotExist($path, $filePath, $message, $folder);
            }
        }
        */

        public function LogTabusRequests( $message, $folder)
        {
            $path  = "C:" . DIRECTORY_SEPARATOR . "Logs". DIRECTORY_SEPARATOR;
            $path1 = $path . DIRECTORY_SEPARATOR . $folder;
            $filePath = $path1 . DIRECTORY_SEPARATOR . date('d_m_Y')."_requests.txt";
            if (is_dir($path))
            {
                if (is_dir($path1))
                {
                    if (file_exists($filePath))
                    {
                        $fl=fopen($filePath, "r+");
                        $size= filesize($filePath);
                        $text = fread($fl,$size);
                        $text = PHP_EOL.PHP_EOL. date('Y-m-d H:i:s') .  $message;
                        fwrite($fl, $text);
                        fclose($fl);

                    }
                    else
                    {
                        $message = date('Y-m-d H:i:s').  $message;
                        $this->FileNotExist($filePath, $message);
                    }
                }
                else
                {
                    $message = date('Y-m-d H:i:s') .  $message;
                    $this->DirNotExist($path1, $filePath, $message, "");
                }
            }
            else
            {
                $message =  date('Y-m-d H:i:s') .  $message;
                $this->DirNotExist($path, $filePath, $message, $folder);
            }
        }

        public function LogTabusSucces($message, $folder)
        {
            $path  = "C:" . DIRECTORY_SEPARATOR . "Logs";
            $path1 = $path . DIRECTORY_SEPARATOR . $folder;
            $filePath = $path1 . DIRECTORY_SEPARATOR . date('d_m_Y')."_success.txt";
            if (is_dir($path))
            {
                if (is_dir($path1))
                {
                    if (file_exists($filePath))
                    {
                        $fl=fopen($filePath, "r+");
                        $size= filesize($filePath);
                        $text = fread($fl,$size);
                        $text = date('Y-m-d H:i:s') .  $message.PHP_EOL;
                        fwrite($fl, $text);
                        fclose($fl);
                    }
                    else
                    {
                        $message = date('Y-m-d H:i:s'). $message;
                        $this->FileNotExist($filePath, $message);
                    }
                }
                else
                {
                    $message = date('Y-m-d H:i:s') .  $message;
                    $this->DirNotExist($path1, $filePath, $message, "");
                }
            }
            else
            {
                $message = date('Y-m-d H:i:s') .  $message;
                $this->DirNotExist($path, $filePath, $message, $folder);
            }
        }

        public function LogTabusErrors($message, $folder)
        {
            $path  = "C:" . DIRECTORY_SEPARATOR . "Logs". DIRECTORY_SEPARATOR . "Tabus";
            $path1 = $path . DIRECTORY_SEPARATOR . $folder;
            $filePath = $path1 . DIRECTORY_SEPARATOR . date('d_m_Y')."_errors.txt";
            if (is_dir($path))
            {
                if (is_dir($path1))
                {
                    if (file_exists($filePath))
                    {
                        $fl=fopen($filePath, "r+");
                        $size= filesize($filePath);
                        $text = fread($fl,$size);
                        $text = $text ."\n[" . date('Y-m-d H:i:s') .  $message;
                        fwrite($fl, $text);
                        fclose($fl);
                    }
                    else
                    {
                        $message = date('Y-m-d H:i:s').  $message;
                        $this->FileNotExist($filePath, $message);
                    }
                }
                else
                {
                    $message = date('Y-m-d H:i:s') . $message;
                    $this->DirNotExist($path1, $filePath, $message, "");
                }
            }
            else
            {
                $message = date('Y-m-d H:i:s') .  $message;
                $this->DirNotExist($path, $filePath, $message, $folder);
            }
        }

        public function LogServerErrors($message, $folder)
        {
            $path  = "C:" . DIRECTORY_SEPARATOR . "Logs". DIRECTORY_SEPARATOR . "Tabus";
            $path1 = $path . DIRECTORY_SEPARATOR . $folder;
            $filePath = $path1 . DIRECTORY_SEPARATOR . date('d_m_Y')."_server_errors.txt";
            if (is_dir($path))
            {
                if (is_dir($path1))
                {
                    if (file_exists($filePath))
                    {
                        $fl=fopen($filePath, "r+");
                        $size= filesize($filePath);
                        $text = fread($fl,$size);
                        $text = $text ."\n[" . date('Y-m-d H:i:s') .  $message;
                        fwrite($fl, $text);
                        fclose($fl);
                    }
                    else
                    {
                        $message = date('Y-m-d H:i:s'). $message;
                        $this->FileNotExist($filePath, $message);
                    }
                }
                else
                {
                    $message = date('Y-m-d H:i:s') . $message;
                    $this->DirNotExist($path1, $filePath, $message, "");
                }
            }
            else
            {
                $message =  date('Y-m-d H:i:s') .  $message;
                $this->DirNotExist($path, $filePath, $message, $folder);
            }
        }
        
        
}
